import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(root, 'public');
const PORT = Number(process.env.PORT || 3000);
const DATA_FILE = path.resolve(root, process.env.DATA_FILE || 'data/rooms.json');
const ROOM_TTL = 7 * 24 * 60 * 60 * 1000;
const MAX_ROOMS = 250;
const MAX_MESSAGE = 4500;
const MAX_MESSAGES = 60;
const CHANNELS = new Map();
const visitors = new Map();
const seen = new Map();
let rooms = new Map();

function stamp() { return Date.now(); }
function sha(text) { return crypto.createHash('sha256').update(text).digest('hex'); }
function safeEqual(a, b) { try { return crypto.timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex')); } catch { return false; } }
function random(n=24) { return crypto.randomBytes(n).toString('base64url'); }
function roomID() { return crypto.randomBytes(5).toString('hex').toUpperCase(); }
function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }
function reqIP(req) { return req.socket.remoteAddress || 'unknown'; }
function rateLimit(req, type, count, interval) {
  const key = `${reqIP(req)}:${type}`, now=stamp(), previous = (visitors.get(key) || []).filter(t => now-t<interval);
  if (previous.length >= count) return false;
  previous.push(now); visitors.set(key, previous); return true;
}
function cleanRooms() {
  let dirty = false;
  for (const [id,r] of rooms) if (stamp()-r.updatedAt > ROOM_TTL) { rooms.delete(id); CHANNELS.delete(id); dirty = true; }
  for (const [key,arr] of visitors) { const recent=arr.filter(t=>stamp()-t<60*60*1000); if(recent.length) visitors.set(key,recent); else visitors.delete(key); }
  for (const [key,t] of seen) if (stamp()-t>60*60*1000) seen.delete(key);
  if (dirty) save();
}
function load() {
  try {
    const list = JSON.parse(fs.readFileSync(DATA_FILE,'utf8'));
    rooms = new Map((Array.isArray(list)?list:[]).filter(r=>r && stamp()-r.updatedAt<ROOM_TTL).map(r=>[r.id,r]));
  } catch (err) { if(err.code!=='ENOENT') console.warn('Cannot read stored rooms:',err.message); }
}
function save() {
  fs.mkdirSync(path.dirname(DATA_FILE), {recursive:true,mode:0o700});
  const tmp = `${DATA_FILE}.${process.pid}.tmp`;
  fs.writeFileSync(tmp,JSON.stringify([...rooms.values()]),{mode:0o600});
  fs.renameSync(tmp,DATA_FILE);
}
function headers(extra={}) { return {
  'X-Content-Type-Options':'nosniff',
  'Referrer-Policy':'no-referrer',
  'X-Frame-Options':'DENY',
  'Cross-Origin-Resource-Policy':'same-origin',
  'Content-Security-Policy': "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
  ...extra
}; }
function json(res,code,payload) { res.writeHead(code,headers({'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}));res.end(JSON.stringify(payload)); }
function fail(res,code,msg) {json(res,code,{error:msg});}
async function readJSON(req) {
  const type = (req.headers['content-type']||'').split(';')[0].trim();
  if(type!=='application/json') throw {code:415,message:'請使用 JSON 格式'};
  let raw='', size=0;
  for await (const chunk of req) {
    size+=chunk.length;
    if(size>12000) throw {code:413,message:'內容超過上限'};
    raw+=chunk.toString('utf8');
  }
  try {return JSON.parse(raw || '{}');} catch {throw {code:400,message:'JSON 格式錯誤'};}
}
function auth(req) {
  const bearer = (req.headers.authorization||'').match(/^Bearer\s+([A-F0-9]{10})\.([ab])\.([A-Za-z0-9_-]{20,100})$/);
  if(!bearer) return null;
  const [_,id,side,token] = bearer;
  const r=rooms.get(id);
  if(!r || !safeEqual(sha(token),r.tokens[side])) return null;
  seen.set(`${id}:${side}`,stamp());
  return {r,side};
}
function currentTurn(r) {return r.messages.length%2===0 ? r.first : r.first==='a'?'b':'a';}
function online(r) {return {
  a: stamp()-(seen.get(`${r.id}:a`)||0)<38000,
  b: stamp()-(seen.get(`${r.id}:b`)||0)<38000
};}
function view(r,role) {return {
  id:r.id,topic:r.topic,tone:r.tone,first:r.first,rounds:r.rounds,side:role,done:r.messages.length>=r.rounds*2,
  next:currentTurn(r),messages:r.messages, online:online(r), createdAt:r.createdAt, updatedAt:r.updatedAt, version:r.version
};}
function sseSend(response,obj) {try {response.write(`data: ${JSON.stringify(obj)}\n\n`);} catch {}}
function broadcast(r) {for(const c of CHANNELS.get(r.id)||[]) sseSend(c.res,{type:'state',state:view(r,c.side)});}
function notify(r) {r.updatedAt=stamp();r.version++;save();broadcast(r);}
function permittedOrigin(req) {
  const origin=req.headers.origin;
  if (!origin) return true;
  let expected=process.env.PUBLIC_ORIGIN;
  if(!expected) {
    const host=req.headers.host;
    const proto=(req.headers['x-forwarded-proto']==='https'?'https': req.socket.encrypted?'https':'http');
    expected=`${proto}://${host}`;
  }
  return origin===expected;
}
function staticFile(res,pathname) {
  const allowed = {'/':'index.html','/index.html':'index.html','/app.js':'app.js','/style.css':'style.css'};
  const file=allowed[pathname];
  if(!file) return fail(res,404,'頁面不存在');
  const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8'};
  try {
    res.writeHead(200,headers({'Content-Type':types[path.extname(file)],'Cache-Control':'no-store'}));
    fs.createReadStream(path.join(publicDir,file)).pipe(res);
  } catch {fail(res,404,'無法讀取檔案');}
}
function createRoom(res,b) {
  if (rooms.size>=MAX_ROOMS) return fail(res,503,'目前房間已滿');
  const topic=String(b.topic||'').trim(),tone=String(b.tone||'友善互嗆').trim();
  if(topic.length<2||topic.length>100) return fail(res,400,'主題請填 2～100 字');
  if(!['友善互嗆','理性辯論','創意挑戰','輕鬆聊天'].includes(tone)) return fail(res,400,'互動風格不正確');
  if(!Number.isInteger(b.rounds)||b.rounds<1||b.rounds>20) return fail(res,400,'回合數限 1～20');
  if(!['a','b'].includes(b.first))return fail(res,400,'先手設定不正確');
  const id=roomID(), a=random(),bToken=random(), now=stamp();
  const r={id,topic,tone,rounds:b.rounds,first:b.first,tokens:{a:sha(a),b:sha(bToken)},messages:[],createdAt:now,updatedAt:now,version:0};
  rooms.set(id,r);save();
  json(res,201,{id,host:`${id}.a.${a}`,guest:`${id}.b.${bToken}`,state:view(r,'a')});
}
function exportText(r) {
  return '小川川 × 笨笨｜雙人真實 AI 對話\n主題：'+r.topic+'\n\n'+r.messages.map((m,i)=>`【${i+1}｜${m.side==='a'?'小川川':'笨笨'}】\n${m.text}`).join('\n\n');
}
async function handler(req,res) {
  const url = new URL(req.url, 'http://localhost');
  const p=url.pathname;
  if(req.method==='GET'&&p==='/healthz')return json(res,200,{status:'ok'});
  if(!p.startsWith('/api/')) {
    if(req.method!=='GET')return fail(res,405,'不支援的請求');
    return staticFile(res,p);
  }
  if(req.method==='POST'&&!permittedOrigin(req))return fail(res,403,'跨站請求被拒絕');
  if(req.method==='POST'&&p==='/api/rooms') {
    if(!rateLimit(req,'create',12,60*60*1000))return fail(res,429,'建立房間過於頻繁');
    return createRoom(res,await readJSON(req));
  }
  const user=auth(req);
  if(!user)return fail(res,401,'邀請連結無效，或房間已過期');
  const {r,side}=user;
  if(p==='/api/state' && req.method==='GET') return json(res,200,{state:view(r,side)});
  if(p==='/api/events' && req.method==='GET') {
    const clients=CHANNELS.get(r.id)||new Set();
    if(clients.size>=12)return fail(res,429,'連線數量已滿');
    res.writeHead(200,headers({'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'}));
    res.write(': connected\n\n');
    const client={res,side};clients.add(client); CHANNELS.set(r.id,clients);
    sseSend(res,{type:'state',state:view(r,side)});broadcast(r);
    const heartbeat=setInterval(()=>{sseSend(res,{type:'ping'});},20000);
    const close=()=>{clearInterval(heartbeat);clients.delete(client);if(!clients.size)CHANNELS.delete(r.id);};
    res.on('close',close);return;
  }
  if(p==='/api/messages'&&req.method==='POST') {
    if(!rateLimit(req,'msg',50,60*1000)) return fail(res,429,'操作太頻繁');
    const b=await readJSON(req), message=String(b.text||'').trim();
    if(!message||message.length>MAX_MESSAGE)return fail(res,400,`回答請填 1～${MAX_MESSAGE} 字`);
    if(r.messages.length>=r.rounds*2)return fail(res,409,'已結束指定回合');
    if(r.messages.length>=MAX_MESSAGES)return fail(res,409,'已達發言上限');
    if(currentTurn(r)!==side)return fail(res,403,'還沒輪到你的 AI');
    if(b.expectedCount!==r.messages.length)return fail(res,409,'資料已更新，請重新確認後送出');
    r.messages.push({side,text:message,at:stamp()});notify(r);
    return json(res,200,{state:view(r,side)});
  }
  if(p==='/api/extend'&&req.method==='POST') {
    if(side!=='a')return fail(res,403,'只有房主可以加賽');
    if(r.rounds>=20)return fail(res,409,'已達 20 回合上限');
    r.rounds=clamp(r.rounds+1,1,20);notify(r);return json(res,200,{state:view(r,side)});
  }
  if(p==='/api/reset'&&req.method==='POST') {
    if(side!=='a')return fail(res,403,'只有房主可以重新開局');
    const b=await readJSON(req),topic=String(b.topic||'').trim();
    if(topic.length<2||topic.length>100)return fail(res,400,'主題請填 2～100 字');
    if(!Number.isInteger(b.rounds)||b.rounds<1||b.rounds>20)return fail(res,400,'回合數需介於 1～20');
    if(!['a','b'].includes(b.first))return fail(res,400,'先手設定不正確');
    if(!['友善互嗆','理性辯論','創意挑戰','輕鬆聊天'].includes(b.tone))return fail(res,400,'互動風格不正確');
    r.topic=topic;r.rounds=b.rounds;r.first=b.first;r.tone=b.tone;r.messages=[];notify(r);
    return json(res,200,{state:view(r,side)});
  }
  if(p==='/api/delete'&&req.method==='POST') {
    if(side!=='a')return fail(res,403,'只有房主可以解散房間');
    for(const client of CHANNELS.get(r.id)||[]) {sseSend(client.res,{type:'deleted'});client.res.end();}
    CHANNELS.delete(r.id);rooms.delete(r.id);save();return json(res,200,{ok:true});
  }
  return fail(res,404,'此功能不存在');
}
load();
const server=http.createServer((req,res)=>{
  Promise.resolve(handler(req,res)).catch(e=>{
    if(!res.headersSent)fail(res,e?.code && Number.isInteger(e.code)?e.code:500,e?.code?'操作失敗：'+e.message:'伺服器發生錯誤');
    else res.end();
    if(!e?.code)console.error('Server error:',e);
  });
});
server.listen(PORT,'0.0.0.0',()=>console.log(`AI duel sync running on http://localhost:${PORT}`));
const gc=setInterval(cleanRooms,60*60*1000);gc.unref();
export {server};
